"""One private original MRT/ZF search only; no MA, FPA or MC evaluator.

The initialization and four numerical statements in each mode are extracted
from the frozen original entry. No original point ownership/closed marker is
created. Only a separately closed theory directory can later be moved.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse, ast, copy, hashlib, importlib.util, json, os, shutil, sys, traceback

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(v): return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def need(v,s):
    if not v: raise RuntimeError(s)
def load(p,name):
    spec=importlib.util.spec_from_file_location(name,p)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def dump_ast(nodes): return ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False)
def extract_original_blocks(source):
    tree=ast.parse(Path(source).read_text(encoding='utf-8-sig'))
    function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='execute')
    def exact_call(n,name):
        return isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id==name
    boundary=next(i for i,n in enumerate(function.body) if exact_call(n,'same_binding'))
    prefix=copy.deepcopy(function.body[:boundary+1])
    original_try=next(n for n in function.body if isinstance(n,ast.Try))
    original_loop=next(n for n in original_try.body if isinstance(n,ast.For))
    # Original model, original spacing operands, original spacing guard, search.
    numerical=copy.deepcopy(original_loop.body[:4])
    need(isinstance(numerical[-1],ast.Assign) and isinstance(numerical[-1].value,ast.Call)
         and isinstance(numerical[-1].value.func,ast.Name) and numerical[-1].value.func.id=='search',
         'Frozen original loop schema changed')
    return function,prefix,original_loop,numerical
def publication_files(unit):
    need({p.name for p in unit.iterdir()}=={'binding.json','grid-MRT','grid-ZF'},'Unexpected publication-unit top-level files')
    out={}
    allowed={'binding.json','checkpoint.json','last-returned-batch.pickle','pruned-prefix-certificates.frames'}
    for mode in ['MRT','ZF']:
        folder=unit/f'grid-{mode}'
        need(folder.is_dir() and not folder.is_symlink(),'Invalid grid folder')
        need(all(p.is_file() and not p.is_symlink() and p.name in allowed for p in folder.iterdir()),
             'Uncertain inflight/pending/unexpected grid artifacts retained; not publishable')
        state=json.loads((folder/'checkpoint.json').read_bytes())
        need(state['complete'] is True and state['stack']==[] and state['best'] is not None and state['winner'] is not None,
             'Original complete grid return required')
        cert=folder/'pruned-prefix-certificates.frames'
        need((cert.stat().st_size if cert.exists() else 0)==state['certificate_bytes'],'Original certificate length differs')
    for p in sorted(unit.rglob('*')):
        if p.is_file():out[p.relative_to(unit).as_posix()]=dict(SHA256=sha(p),bytes=p.stat().st_size)
    return out

def main(args):
    need(sys.dont_write_bytecode and not sys.flags.optimize,'Use -X utf8 -B without -O')
    plan=json.loads(args.plan.read_bytes());admission=json.loads(args.admission.read_bytes())
    need(args.execute and admission.get('root_admitted_only_private_original_Fig20_D3g0_theory_grids') is True,
         'Exact root theory-only admission required')
    need(admission['theory_plan_SHA256']==sha(args.plan),'Theory plan changed')
    need(admission['root_admitted_statistical_grid_fixed1000'] is True,
         'Unchanged original initializer admission flag is still false')
    private=Path(plan['private_run_directory']);unit=Path(plan['publication_unit'])
    need(not private.exists(),'Private run exists; never automatically retry original search')
    need(not Path(plan['canonical_future_point']).exists(),'Parent already claimed future point; no ahead run')
    need(unit.parent==private and unit.name=='grid-publication-unit','Unexpected private unit')
    need(shutil.disk_usage(private.parent).free>=plan['minimum_free_bytes'],'Low storage; no theory search started')
    expected=dict(plan['source_pins']);expected[str(args.plan)]=sha(args.plan);expected[str(args.admission)]=sha(args.admission)
    original_plan=json.loads(Path(plan['original_plan']).read_bytes())
    need(sha(plan['original_plan'])==plan['original_plan_SHA256'],'Original plan changed')
    expected.update(original_plan['source_pins'])
    overlay=json.loads(Path(plan['overlay']).read_bytes())
    for p,want in [(Path(plan['overlay']),plan['overlay_SHA256']),
                   (Path(plan['bank'])/'manifest.json',overlay['manifest_SHA256']),
                   (Path(plan['bank'])/'run_config.json',overlay['original_configuration_SHA256']),
                   (Path(overlay['execution_configuration']),overlay['execution_configuration_SHA256'])]:
        expected[str(p)]=want
    jobfile=Path(plan['bank'])/'jobs'/plan['filename'];expected[str(jobfile)]=sha(jobfile)
    before={p:sha(p) for p in expected};need(before==expected,'Frozen source/input differs before run')
    private.mkdir(parents=True,exist_ok=False)
    report=dict(schema='actual-private-original-Fig20-theory-grid-only-v1',modes=[],errors=[],
                actual_original_optimizer_FPA_instantaneous_MCdraw_RNG_calls=0,
                full_point_or_MA_or_MC_or_figure_or_reference_PASS=False,
                historical_author_target_recovered=False)
    code=1
    try:
        entry=Path(plan['original_entry']);sys.path.insert(0,str(entry.parent))
        module=load(entry,'_frozen_original_Fig20_singlepoint_entry')
        need(Path(module.search.__code__.co_filename).resolve()==Path(plan['original_bounded_source']).resolve(),
             'Wrong original bounded search imported')
        function,prefix,loop,numerical=extract_original_blocks(entry)
        need(hashlib.sha256(dump_ast(prefix).encode()).hexdigest()==plan['exact_original_prefix_AST_SHA256'],'Original initializer AST differs')
        need(hashlib.sha256(dump_ast(numerical).encode()).hexdigest()==plan['exact_original_four_search_statements_AST_SHA256'],'Original search AST differs')
        initializer=copy.deepcopy(function);initializer.name='_actual_original_init_without_point_owner'
        initializer.body=prefix+ast.parse('return dict(c=c,exact=exact,np=np,before=before,binding=binding,job=job,config=config,plan=plan)').body
        namespace=dict(module.__dict__)
        exec(compile(ast.fix_missing_locations(ast.Module(body=[initializer],type_ignores=[])),str(entry),'exec'),namespace)
        context=namespace[initializer.name](SimpleNamespace(plan=Path(plan['original_plan']),overlay=Path(plan['overlay']),
            admission=args.admission,bank=Path(plan['bank']),filename=plan['filename'],output_dir=unit,execute=True))
        need(context['job']['figure']==20 and context['job']['realization']==0 and context['job']['N']==6
             and context['job']['M']==5 and context['job']['point']==3,'Not original Fig20 D3/g0')
        need(context['binding']['original_input_fingerprint']==plan['original_input_fingerprint'],'Wrong original manifest slot')
        report['original_point_binding']=context['binding']
        def observe(mode,model,best,winner,state):
            folder=unit/f'grid-{mode}'
            need(state==json.loads((folder/'checkpoint.json').read_bytes()),'Returned state not exact committed checkpoint')
            report['modes'].append(dict(mode=mode,actual_frozen_model=module.actual_model_identity(model),
                original_exact_product=module.fraction_pair(best),original_winner_zero_based=list(winner),
                original_complete=state['complete'],original_stack=state['stack'],
                nodes=state['nodes'],leaves=state['leaves'],prunes=state['prunes'],
                certificate_bytes=state['certificate_bytes']))
            module.atomic(private/'progress.json',dict(completed_modes=[r['mode'] for r in report['modes']],
                scope='private original two statistical grids only; no point/MA/MC PASS'))
        actual_loop=copy.deepcopy(loop);actual_loop.body=numerical+ast.parse('_observe(mode,model,best,winner,state)').body
        namespace.update(context,_observe=observe,admission=admission,output=unit)
        exec(compile(ast.fix_missing_locations(ast.Module(body=[actual_loop],type_ignores=[])),str(entry),'exec'),namespace)
        need(len(report['modes'])==2 and {r['mode'] for r in report['modes']}=={'MRT','ZF'},'Both original grids required')
        report['publication_files']=publication_files(unit)
        report['actual_complete_two_original_theory_grids']=True
        code=0
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
        report['actual_complete_two_original_theory_grids']=False
    finally:
        after={}
        for p in expected:
            try:after[p]=sha(p)
            except OSError as error:report['errors'].append(dict(path=p,type=type(error).__name__,message=str(error)))
        report.update(source_input_before=before,source_input_after=after,
                      source_input_interval_closed=before==after==expected)
        if not report['source_input_interval_closed']:code=1
        report['actual_theory_process_exit_code']=code
        report['independent_global_certificate_PASS']=False
        report['scientific_scope']='Original search return/capture only; independent actual certificate reader pending.'
        (private/'ACTUAL_PRIVATE_ORIGINAL_FIG20_TWO_THEORY_GRIDS_SOURCE_CLOSURE_V1.json').write_bytes(enc(report)+b'\n')
    print(json.dumps(dict(exit_code=code,completed_modes=len(report['modes']),source_input_closed=report['source_input_interval_closed'],full_point_PASS=False)))
    return code
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',type=Path,required=True);p.add_argument('--admission',type=Path,required=True);p.add_argument('--execute',action='store_true')
    raise SystemExit(main(p.parse_args()))
